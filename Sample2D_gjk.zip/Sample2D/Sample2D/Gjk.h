#pragma once

struct Body;
struct Shape;

struct SimplexVertex
{
    Vector2 witnessA;
    Vector2 witnessB;
    Vector2 point;
};

struct Gjk
{
    Gjk(Body* a, Body* b, float margin);
    bool Collide();
    SimplexVertex GetPoint(const Vector2& v) const;

    // Determines the closest point on the current simplex to the origin.
    // This will drop unnecessary points to return the minimal simplex.
    // Returns true if resulting simplex contains the origin
    bool GetClosestPoint(Vector2* closestPoint);
    // implementation for 1-simplex (segment)
    bool GetClosestPoint1(Vector2* closestPoint);
    // implementation for 2-simplex (triangle)
    bool GetClosestPoint2(Vector2* closestPoint);

    void GenerateContactInfo();
    void FindClosestPointOnCSOSurface();    // EPA

    Body* body1;
    Body* body2;
    float margin;

    // temp cached values
    Shape* shapeA, *shapeB;
    Vector2 posA, posB;
    Matrix2 rotA, rotB;
    Matrix2 invRotA, invRotB;
    Vector2 v;

    // Simplex
    SimplexVertex points[3];
    int numPoints;

    // Contact
    Vector2 contactNormal;
    float separation;

    // EPA
    struct Edge
    {
        SimplexVertex a, b;
    };

    Vector2 closestPointOnCSOSurface;
    Edge closestEdge;

    // Returns index of which edge in the list is closest to the origin
    int FindClosestEdge(Edge* edges, int numEdges, Vector2* closestPoint);
};
