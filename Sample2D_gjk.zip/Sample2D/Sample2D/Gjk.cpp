#include "Precomp.h"
#include "Gjk.h"
#include "Body.h"
#include "Shape.h"

Gjk::Gjk(Body* a, Body* b, float margin)
    : body1(a)
    , body2(b)
    , margin(margin)
    , v(0, 1)
    , separation(0.0f)
{
}

bool Gjk::Collide()
{
    SimplexVertex w;    // current point
    Vector2 closest;
    float vDotw = 0.0f;
    float distSq = FLT_MAX;

    // Setup
    shapeA = body1->shape;
    shapeB = body2->shape;
    posA = body1->position;
    posB = body2->position;
    rotA = Matrix2(body1->rotation);
    rotB = Matrix2(body2->rotation);
    invRotA = rotA.Transpose();
    invRotB = rotB.Transpose();

    points[0] = GetPoint(v);
    numPoints = 1;
    v = -points[0].point;

    for (;;)
    {
        // Get point
        w = GetPoint(v.GetNormalized());
        vDotw = Dot(v, w.point);
        if (vDotw < 0)
        {
            // Can't reach the origin (outside of CSO). No contact
            return false;
        }

        points[numPoints++] = w;

        // If we made a triangle, make sure winding is clockwise
        // (code in GetClosestPoint makes this assumption).
        if (numPoints == 3)
        {
            if (Dot(points[2].point - points[0].point, Cross(points[1].point - points[0].point, -1.0f)) > 0)
            {
                // reverse a & b
                SimplexVertex temp = points[0];
                points[0] = points[1];
                points[1] = temp;
            }
        }

        if (GetClosestPoint(&closest))
        {
            GenerateContactInfo();
            return true;
        }

        float d2 = closest.GetLengthSq();
        if (d2 > distSq - 0.0001f)
        {
            // Not getting any closer
            return false;
        }

        distSq = d2;

        v = -closest;
    }
}

SimplexVertex Gjk::GetPoint(const Vector2& v) const
{
    // return point from A-B minkowski sum
    SimplexVertex vertex;
    vertex.witnessA = posA + rotA * shapeA->GetSupportV(invRotA * v, margin, nullptr);
    vertex.witnessB = posB + rotB * shapeB->GetSupportV(invRotB * -v, margin, nullptr);
    vertex.point = vertex.witnessA - vertex.witnessB;
    return vertex;
}

bool Gjk::GetClosestPoint(Vector2* closest)
{
    switch (numPoints)
    {
    case 1: // single point, trivial case
        *closest = points[0].point;
        return (closest->GetLengthSq() < 0.0001f);

    case 2: // line segment
        return GetClosestPoint1(closest);

    case 3: // triangle
        return GetClosestPoint2(closest);

    default:
        _ASSERT(false);
        return false;
    }
}

bool Gjk::GetClosestPoint1(Vector2* closest)
{
    Vector2 dir = (points[1].point - points[0].point).GetNormalized();
    Vector2 aToOrigin = -points[0].point;

    float extent = Dot(dir, points[1].point - points[0].point);
    float s = Dot(dir, aToOrigin);
    if (s <= 0)
    {
        // contact[0] is closest, contact[1] is unnecessary
        *closest = points[0].point;
        numPoints = 1;
        return false;   // vertex can't be it, since we would have caught prior to getting to segment
    }
    else if (s >= extent)
    {
        // contact[1] is closest, contact[0] is unnecessary
        points[0] = points[1];
        *closest = points[0].point;
        numPoints = 1;
        return false;   // vertex can't be it, since we would have caught prior to getting to segment
    }
    else
    {
        *closest = points[0].point + dir * s;
        return (closest->GetLengthSq() < 0.0001f);
    }
}

bool Gjk::GetClosestPoint2(Vector2* closest)
{
    Vector2 ab = (points[1].point - points[0].point).GetNormalized();
    Vector2 bc = (points[2].point - points[1].point).GetNormalized();
    Vector2 ca = (points[0].point - points[2].point).GetNormalized();

    float dAB = Dot(-points[0].point, Cross(ab, -1.0f));
    float dBC = Dot(-points[1].point, Cross(bc, -1.0f));
    float dCA = Dot(-points[2].point, Cross(ca, -1.0f));

    if (dAB >= 0)   // Is outside of AB?
    {
        // either in A vertex, B, vertex, or AB edge voronoi region
        if (dCA >= 0)   // Is outside of CA?
        {
            // A vertex region
            *closest = points[0].point;
            // Drop all other points but A
            numPoints = 1;
            return (closest->GetLengthSq() < 0.0001f);
        }
        else if (dBC >= 0)  // Outside of BC?
        {
            // B vertex region
            *closest = points[1].point;
            // Drop all other points but B
            points[0] = points[1];
            numPoints = 1;
            return (closest->GetLengthSq() < 0.0001f);
        }
        else
        {
            // AB edge region
            *closest = points[0].point + ab * Dot(-points[0].point, ab);
            // drop C
            numPoints = 2;
            return (closest->GetLengthSq() < 0.0001f);
        }
    }
    else
    {
        // Inside of AB.
        if (dBC >= 0)   // outside of BC
        {
            if (dCA >= 0)   // and outside of CA?
            {
                // c vertex region
                *closest = points[2].point;
                // drop all but C
                points[0] = points[2];
                numPoints = 1;
                return (closest->GetLengthSq() < 0.0001f);
            }
            else
            {
                // bc edge region
                *closest = points[1].point + bc * Dot(-points[1].point, bc);
                // drop A
                points[0] = points[1];
                points[1] = points[2];
                numPoints = 2;
                return (closest->GetLengthSq() < 0.0001f);
            }
        }
        else
        {
            if (dCA >= 0)
            {
                // CA edge region
                *closest = points[2].point + ca * Dot(-points[2].point, ca);
                // drop B
                points[1] = points[2];
                numPoints = 2;
                return (closest->GetLengthSq() < 0.0001f);
            }
            else
            {
                // inside triangle
                *closest = Vector2(0, 0);
                return true;
            }
        }
    }
}

void Gjk::GenerateContactInfo()
{
    FindClosestPointOnCSOSurface();
    contactNormal = closestPointOnCSOSurface.GetNormalized();
    if (Dot(body1->position - closestEdge.a.witnessB, contactNormal) > 0)
    {
        contactNormal = -contactNormal;
    }
    separation = -closestPointOnCSOSurface.GetLength();
}

void Gjk::FindClosestPointOnCSOSurface()
{
    Edge edges[64] = {};
    int numEdges = 0;

    // Initialize with final simplex
    _ASSERT(numPoints == 2 || numPoints == 3);
    edges[0].a = points[0];
    edges[0].b = points[1];
    ++numEdges;
    if (numPoints == 3)
    {
        edges[1].a = points[1];
        edges[1].b = points[2];
        ++numEdges;
        edges[2].a = points[2];
        edges[2].b = points[0];
        ++numEdges;
    }

    // Iterate outward, removing the currently closest edge to the origin, and
    // replacing it with 2 new edges from it's previous endpoints to the new vertex.
    // If no new vertex can be found, then edge is the closest to the surface. Find
    // closest point on that edge to the origin.

    Vector2 closestPoint;
    int iClosest = FindClosestEdge(edges, numEdges, &closestPoint);
    if (closestPoint.GetLengthSq() < 0.0001f)
    {
        // contact is on the edge
        closestPointOnCSOSurface = closestPoint;
        closestEdge = edges[iClosest];
        return;
    }
    v = closestPoint.GetNormalized();
    SimplexVertex w = GetPoint(v);

    while (Dot(v, w.point) > Dot(v, closestPoint) + 0.1f)
    {
        // replace iClosest with 2 new edges containing w
        Edge prev = edges[iClosest];
        edges[iClosest].b = w;
        edges[numEdges].a = w;
        edges[numEdges].b = prev.b;
        ++numEdges;

        iClosest = FindClosestEdge(edges, numEdges, &closestPoint);
        v = closestPoint.GetNormalized();
        if (closestPoint.GetLengthSq() < 0.0001f)
        {
            // contact is on the edge
            closestPointOnCSOSurface = closestPoint;
            closestEdge = edges[iClosest];
            return;
        }
        w = GetPoint(v);
    }

    closestPointOnCSOSurface = closestPoint;
    closestEdge = edges[iClosest];
}

int Gjk::FindClosestEdge(Edge* edges, int numEdges, Vector2* closestPoint)
{
    int iMin = -1;
    float minDist = FLT_MAX, d;
    Vector2 minP, p;
    Vector2 dir;

    for (int i = 0; i < numEdges; ++i)
    {
        dir = (edges[i].b.point - edges[i].a.point).GetNormalized();
        float value = Dot(-edges[i].a.point, dir);
        if (value <= 0)
        {
            p = edges[i].a.point;
        }
        else if (value >= Dot(edges[i].b.point - edges[i].a.point, dir))
        {
            p = edges[i].b.point;
        }
        else
        {
            p = edges[i].a.point + dir * value;
        }
        d = p.GetLength();
        if (iMin < 0 || d < minDist)
        {
            iMin = i;
            minP = p;
            minDist = d;
        }
    }

    *closestPoint = minP;
    return iMin;
}
