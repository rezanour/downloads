#pragma once


#include "Manifold.h"

struct Body;
class SpriteBatch2;
class Texture;

class PhysicsWorld
{
public:
    PhysicsWorld(const Vector2& gravity, int iterations);

    void Add(Body* body);
    void Update(float dt);
    void Draw(const std::shared_ptr<SpriteBatch2>& spriteBatch, const std::shared_ptr<Texture>& contactSprite);

private:
    void UpdateManifolds();

    std::vector<Body*> bodies;
    std::map<PairKey, Manifold> manifolds;
    Vector2 gravity;
    int iterations;
};
